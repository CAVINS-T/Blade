# Blade App

A Flutter app to analyze and improve your golf swing using AI and sensor data.